module.exports.DEFAULT_SUBREDDITS = [
    'dankmemes',
    'me_irl',
    'wholesomememes',
    'memes',
    'funny'
]